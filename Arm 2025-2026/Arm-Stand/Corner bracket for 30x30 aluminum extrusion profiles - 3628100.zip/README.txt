Corner bracket for 30x30 aluminum extrusion profiles by nikitz on Thingiverse: https://www.thingiverse.com/thing:3628100

Summary:
Corner bracket for my new HyperCube project. It fitts 30x30 AL extrusions profiles. Iam using 5mm screw with flat head and 5mm T Hammer Nut. Screw Length is 12mm. Print it without support.